<?php
/**
 * 記事一覧・アーカイブテンプレート
 */
get_header(); ?>

<main id="main-content" class="site-main page-main" role="main">

    <div class="page-hero">
        <span class="page-hero__deco page-hero__deco--1" aria-hidden="true"></span>
        <span class="page-hero__deco page-hero__deco--2" aria-hidden="true"></span>
        <div class="container">
            <div class="page-hero__inner">
                <p class="page-hero__label">BLOG</p>
                <h1 class="page-hero__title">
                    <?php
                    if ( is_home() ) :
                        single_post_title( '', false ) ?: esc_html_e( '最新のお知らせ', 'daikousetubi' );
                    elseif ( is_archive() ) :
                        the_archive_title();
                    elseif ( is_search() ) :
                        printf( esc_html__( '「%s」の検索結果', 'daikousetubi' ), esc_html( get_search_query() ) );
                    else :
                        esc_html_e( '記事一覧', 'daikousetubi' );
                    endif;
                    ?>
                </h1>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="page-body">
            <?php if ( have_posts() ) : ?>
                <div class="post-list">
                    <?php while ( have_posts() ) : the_post(); ?>
                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
                            <a href="<?php the_permalink(); ?>" class="post-card__thumb">
                                <?php if ( has_post_thumbnail() ) : ?>
                                    <?php the_post_thumbnail( 'medium_large' ); ?>
                                <?php else : ?>
                                    <div class="post-card__placeholder"><?php echo daikousetubi_icon( 'grid' ); ?></div>
                                <?php endif; ?>
                            </a>
                            <div class="post-card__body">
                                <div class="post-card__meta">
                                    <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
                                        <?php echo esc_html( get_the_date() ); ?>
                                    </time>
                                    <?php
                                    $cats = get_the_category();
                                    if ( $cats ) :
                                    ?>
                                    <span class="post-card__cat"><?php echo esc_html( $cats[0]->name ); ?></span>
                                    <?php endif; ?>
                                </div>
                                <h2 class="post-card__title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h2>
                                <p class="post-card__excerpt"><?php echo esc_html( get_the_excerpt() ); ?></p>
                                <a href="<?php the_permalink(); ?>" class="post-card__more">
                                    続きを読む <?php echo daikousetubi_icon( 'arrow' ); ?>
                                </a>
                            </div>
                        </article>
                    <?php endwhile; ?>
                </div>

                <nav class="pagination" aria-label="ページ送り">
                    <?php
                    the_posts_pagination( [
                        'mid_size'  => 2,
                        'prev_text' => '<span aria-hidden="true">‹</span><span class="screen-reader-text">前のページ</span>',
                        'next_text' => '<span aria-hidden="true">›</span><span class="screen-reader-text">次のページ</span>',
                    ] );
                    ?>
                </nav>
            <?php else : ?>
                <div class="no-results">
                    <p>記事が見つかりませんでした。</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

</main>

<?php get_footer(); ?>
