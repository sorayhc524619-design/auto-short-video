<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class( 'has-mobile-cta' ); ?>>
<?php wp_body_open(); ?>

<!-- スクロール進捗バー（JSで幅を制御） -->
<div class="scroll-progress" id="scroll-progress" aria-hidden="true"></div>

<a class="skip-link screen-reader-text" href="#main-content">本文へスキップ</a>

<header class="site-header" id="site-header" role="banner">

    <div class="header-topbar">
        <div class="container">
            <div class="topbar-inner">
                <p class="topbar-hours">
                    <?php echo daikousetubi_icon( 'clock' ); ?>
                    <span>営業時間：<?php echo esc_html( daikousetubi_hours() ); ?></span>
                </p>
                <p class="topbar-tel">
                    <?php echo daikousetubi_icon( 'phone' ); ?>
                    <a href="<?php echo esc_attr( daikousetubi_tel_href() ); ?>" class="topbar-tel__num">
                        <?php echo esc_html( daikousetubi_tel() ); ?>
                    </a>
                    <span class="topbar-tel__note">通話料無料</span>
                </p>
            </div>
        </div>
    </div>

    <div class="header-main">
        <div class="container">
            <div class="header-main__inner">

                <div class="site-branding">
                    <?php if ( has_custom_logo() ) : ?>
                        <?php the_custom_logo(); ?>
                    <?php else : ?>
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo" rel="home">
                            <span class="site-logo__mark" aria-hidden="true">
                                <?php echo daikousetubi_icon( 'water' ); ?>
                            </span>
                            <span class="site-logo__text">
                                <span class="site-logo__name"><?php bloginfo( 'name' ); ?></span>
                                <span class="site-logo__tagline">水道・リフォーム・住宅設備</span>
                            </span>
                        </a>
                    <?php endif; ?>
                </div>

                <nav class="primary-nav" aria-label="<?php esc_attr_e( 'メインナビゲーション', 'daikousetubi' ); ?>">
                    <?php
                    wp_nav_menu( [
                        'theme_location' => 'primary',
                        'menu_class'     => 'nav-menu',
                        'container'      => false,
                        'fallback_cb'    => 'daikousetubi_nav_fallback',
                        'depth'          => 2,
                    ] );
                    ?>
                </nav>

                <button
                    class="hamburger"
                    id="hamburger"
                    type="button"
                    aria-label="メニューを開閉する"
                    aria-controls="drawer-menu"
                    aria-expanded="false">
                    <span class="hamburger__bars" aria-hidden="true">
                        <span></span><span></span><span></span>
                    </span>
                    <span class="hamburger__label">MENU</span>
                </button>

            </div>
        </div>
    </div>

    <div class="drawer" id="drawer-menu" aria-hidden="true">
        <div class="drawer__inner">
            <div class="drawer__tel">
                <p class="drawer__tel-label">お電話でのご相談はこちら</p>
                <a href="<?php echo esc_attr( daikousetubi_tel_href() ); ?>" class="drawer__tel-link">
                    <?php echo daikousetubi_icon( 'phone' ); ?>
                    <span><?php echo esc_html( daikousetubi_tel() ); ?></span>
                </a>
                <p class="drawer__tel-hours"><?php echo esc_html( daikousetubi_hours() ); ?></p>
            </div>
            <nav aria-label="<?php esc_attr_e( 'スマートフォン用ナビゲーション', 'daikousetubi' ); ?>">
                <?php
                wp_nav_menu( [
                    'theme_location' => 'primary',
                    'menu_class'     => 'drawer__menu',
                    'container'      => false,
                    'fallback_cb'    => 'daikousetubi_nav_fallback',
                    'depth'          => 2,
                ] );
                ?>
            </nav>
        </div>
    </div>
    <div class="drawer-overlay" id="drawer-overlay" tabindex="-1"></div>

</header>

<div id="page-wrapper" class="page-wrapper">
