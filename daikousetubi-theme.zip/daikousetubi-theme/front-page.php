<?php
/**
 * トップページテンプレート
 */
get_header(); ?>

<main id="main-content" class="site-main" role="main">

    <section class="hero" aria-labelledby="hero-title">
        <span class="hero__deco hero__deco--1" aria-hidden="true"></span>
        <span class="hero__deco hero__deco--2" aria-hidden="true"></span>
        <span class="hero__deco hero__deco--3" aria-hidden="true"></span>

        <div class="container">
            <div class="hero__grid">
                <div class="hero__content">
                    <span class="hero__badge">
                        <?php echo daikousetubi_icon( 'shield' ); ?>
                        <span>地域密着・年中無休対応</span>
                    </span>
                    <h1 class="hero__title" id="hero-title">
                        水まわりの困った、<br>
                        <span class="hero__title-accent">即解決</span>します。
                    </h1>
                    <p class="hero__lead">
                        地域密着30年。水道工事・リフォーム・住宅設備まで、
                        暮らしの「困った」をワンストップで解決します。
                    </p>
                    <div class="hero__btns">
                        <a href="<?php echo esc_attr( daikousetubi_tel_href() ); ?>" class="btn btn--primary btn--lg">
                            <?php echo daikousetubi_icon( 'phone' ); ?>
                            <span>今すぐ電話で相談</span>
                        </a>
                        <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn btn--outline btn--lg">
                            <?php echo daikousetubi_icon( 'mail' ); ?>
                            <span>無料見積りを依頼</span>
                        </a>
                    </div>
                    <ul class="hero__features">
                        <li><?php echo daikousetubi_icon( 'check' ); ?>年中無休</li>
                        <li><?php echo daikousetubi_icon( 'check' ); ?>最短30分</li>
                        <li><?php echo daikousetubi_icon( 'check' ); ?>見積り無料</li>
                    </ul>
                </div>

                <div class="hero__visual" aria-hidden="true">
                    <div class="hero__card">
                        <div class="hero__card-icon"><?php echo daikousetubi_icon( 'home' ); ?></div>
                        <p class="hero__card-title">水まわりのプロ</p>
                        <p class="hero__card-desc">確かな技術で住まいを守ります</p>
                    </div>
                    <div class="hero__circle hero__circle--1"></div>
                    <div class="hero__circle hero__circle--2"></div>

                    <!-- 浮遊するステータスカード -->
                    <span class="hero__float hero__float--tl">
                        <?php echo daikousetubi_icon( 'star' ); ?>
                        <span><strong>★4.9</strong>&nbsp;お客様満足度</span>
                    </span>
                    <span class="hero__float hero__float--br">
                        <?php echo daikousetubi_icon( 'pin' ); ?>
                        <span><strong>対応エリア</strong>&nbsp;拡大中</span>
                    </span>
                </div>
            </div>
        </div>

        <!-- スクロールインジケーター -->
        <span class="hero__scroll" aria-hidden="true">SCROLL</span>
    </section>

    <!-- 数字で見る実績 -->
    <section class="stats-section" aria-labelledby="stats-title">
        <span class="stats-section__deco" aria-hidden="true"></span>
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">NUMBERS</p>
                <h2 class="section-head__title" id="stats-title">数字で見る実績</h2>
                <p class="section-head__desc">長年の経験と信頼が、確かな品質の証です。</p>
            </header>
            <div class="stats-grid reveal-stagger">
                <div class="stat-item">
                    <span class="stat-item__value">30<span class="stat-item__unit">年</span></span>
                    <span class="stat-item__label">創業</span>
                </div>
                <div class="stat-item">
                    <span class="stat-item__value">10,000<span class="stat-item__unit">件</span></span>
                    <span class="stat-item__label">累計施工</span>
                </div>
                <div class="stat-item">
                    <span class="stat-item__value">98<span class="stat-item__unit">%</span></span>
                    <span class="stat-item__label">満足度</span>
                </div>
                <div class="stat-item">
                    <span class="stat-item__value">365<span class="stat-item__unit">日</span></span>
                    <span class="stat-item__label">年中無休対応</span>
                </div>
            </div>
        </div>
    </section>

    <section class="services" aria-labelledby="services-title">
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">SERVICE</p>
                <h2 class="section-head__title" id="services-title">サービス紹介</h2>
                <p class="section-head__desc">水まわりから住まいまで、幅広いサービスを提供しています。</p>
            </header>

            <div class="service-cards">
                <article class="service-card">
                    <div class="service-card__icon service-card__icon--blue">
                        <?php echo daikousetubi_icon( 'water' ); ?>
                    </div>
                    <h3 class="service-card__title">水道の工事・修理</h3>
                    <p class="service-card__desc">
                        水漏れ・詰まり・給排水管工事まで、<br>
                        水まわりのトラブルに迅速対応します。
                    </p>
                    <ul class="service-card__list">
                        <li>蛇口・水栓の修理・交換</li>
                        <li>トイレの詰まり解消</li>
                        <li>給水管・排水管工事</li>
                    </ul>
                    <a href="<?php echo esc_url( home_url( '/plumbing/' ) ); ?>" class="service-card__link">
                        詳しく見る <?php echo daikousetubi_icon( 'arrow' ); ?>
                    </a>
                </article>

                <article class="service-card">
                    <div class="service-card__icon service-card__icon--cyan">
                        <?php echo daikousetubi_icon( 'home' ); ?>
                    </div>
                    <h3 class="service-card__title">リフォーム</h3>
                    <p class="service-card__desc">
                        キッチン・浴室・トイレから内装・外装まで、<br>
                        住まいのリニューアルをトータルサポート。
                    </p>
                    <ul class="service-card__list">
                        <li>キッチン・浴室・トイレ</li>
                        <li>内装・壁紙・フローリング</li>
                        <li>外壁塗装・屋根工事</li>
                    </ul>
                    <a href="<?php echo esc_url( home_url( '/reform/' ) ); ?>" class="service-card__link">
                        詳しく見る <?php echo daikousetubi_icon( 'arrow' ); ?>
                    </a>
                </article>

                <article class="service-card">
                    <div class="service-card__icon service-card__icon--navy">
                        <?php echo daikousetubi_icon( 'tool' ); ?>
                    </div>
                    <h3 class="service-card__title">住宅設備・機器</h3>
                    <p class="service-card__desc">
                        給湯器・エアコン・ウォシュレットなど、<br>
                        住宅設備の販売・設置・交換を行います。
                    </p>
                    <ul class="service-card__list">
                        <li>給湯器・エコキュート</li>
                        <li>エアコン設置・交換</li>
                        <li>トイレ・洗面台交換</li>
                    </ul>
                    <a href="<?php echo esc_url( home_url( '/equipment/' ) ); ?>" class="service-card__link">
                        詳しく見る <?php echo daikousetubi_icon( 'arrow' ); ?>
                    </a>
                </article>
            </div>
        </div>
    </section>

    <section class="reasons" aria-labelledby="reasons-title">
        <span class="reasons__bg" aria-hidden="true"></span>
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">WHY CHOOSE US</p>
                <h2 class="section-head__title" id="reasons-title">選ばれる理由</h2>
                <p class="section-head__desc">多くのお客様に信頼いただいている4つの理由。</p>
            </header>

            <div class="reason-grid">
                <article class="reason-item">
                    <span class="reason-item__num">01</span>
                    <div class="reason-item__icon"><?php echo daikousetubi_icon( 'zap' ); ?></div>
                    <h3 class="reason-item__title">年中無休・<br>迅速対応</h3>
                    <p class="reason-item__desc">
                        水漏れなどの緊急トラブルも365日対応。
                        ご連絡いただければ最短当日にお伺いします。
                    </p>
                </article>
                <article class="reason-item">
                    <span class="reason-item__num">02</span>
                    <div class="reason-item__icon"><?php echo daikousetubi_icon( 'yen' ); ?></div>
                    <h3 class="reason-item__title">明朗会計・<br>見積無料</h3>
                    <p class="reason-item__desc">
                        作業前に必ずお見積りをご提示。
                        追加料金は一切発生しません。
                    </p>
                </article>
                <article class="reason-item">
                    <span class="reason-item__num">03</span>
                    <div class="reason-item__icon"><?php echo daikousetubi_icon( 'star' ); ?></div>
                    <h3 class="reason-item__title">豊富な実績・<br>有資格者対応</h3>
                    <p class="reason-item__desc">
                        給水装置工事主任技術者など、
                        経験豊富な有資格者が確実に対応します。
                    </p>
                </article>
                <article class="reason-item">
                    <span class="reason-item__num">04</span>
                    <div class="reason-item__icon"><?php echo daikousetubi_icon( 'pin' ); ?></div>
                    <h3 class="reason-item__title">地域密着・<br>アフター充実</h3>
                    <p class="reason-item__desc">
                        地域を知り尽くしたスタッフが対応。
                        施工後のフォローも安心です。
                    </p>
                </article>
            </div>
        </div>
    </section>

    <section class="gallery-section" aria-labelledby="gallery-title">
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">WORKS</p>
                <h2 class="section-head__title" id="gallery-title">施工事例</h2>
                <p class="section-head__desc">これまでの施工事例の一部をご紹介します。</p>
            </header>

            <div class="gallery-grid">
                <?php
                // カスタム投稿タイプ「works」を使う場合は 'post_type' => 'works' に変更してください。
                $works = new WP_Query( [
                    'post_type'      => 'post',
                    'posts_per_page' => 6,
                    'category_name'  => 'works',
                ] );

                if ( $works->have_posts() ) :
                    while ( $works->have_posts() ) : $works->the_post();
                ?>
                <a href="<?php the_permalink(); ?>" class="gallery-item">
                    <div class="gallery-item__img">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <?php the_post_thumbnail( 'daikousetubi-gallery' ); ?>
                        <?php else : ?>
                            <div class="gallery-item__placeholder"><?php echo daikousetubi_icon( 'grid' ); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="gallery-item__info">
                        <span class="gallery-item__cat"><?php
                            $cat = get_the_category();
                            echo esc_html( $cat[0]->name ?? '施工事例' );
                        ?></span>
                        <h3 class="gallery-item__title"><?php the_title(); ?></h3>
                    </div>
                </a>
                <?php
                    endwhile;
                    wp_reset_postdata();
                else :
                    $demo_works = [
                        [ 'cat' => '水道工事', 'title' => 'キッチン蛇口の交換工事' ],
                        [ 'cat' => 'リフォーム', 'title' => '浴室リフォーム施工事例' ],
                        [ 'cat' => '住宅設備', 'title' => 'エコキュート設置工事' ],
                        [ 'cat' => '外溝工事', 'title' => '駐車場コンクリート工事' ],
                        [ 'cat' => 'リフォーム', 'title' => 'トイレ全面リフォーム' ],
                        [ 'cat' => '水道工事', 'title' => '給水管の交換工事' ],
                    ];
                    foreach ( $demo_works as $i => $w ) :
                ?>
                <div class="gallery-item gallery-item--demo">
                    <div class="gallery-item__img">
                        <div class="gallery-item__placeholder"><?php echo daikousetubi_icon( 'grid' ); ?></div>
                    </div>
                    <div class="gallery-item__info">
                        <span class="gallery-item__cat"><?php echo esc_html( $w['cat'] ); ?></span>
                        <h3 class="gallery-item__title"><?php echo esc_html( $w['title'] ); ?></h3>
                    </div>
                </div>
                <?php endforeach; endif; ?>
            </div>

            <div class="gallery-section__more">
                <a href="<?php echo esc_url( home_url( '/works/' ) ); ?>" class="btn btn--outline">
                    施工事例をもっと見る <?php echo daikousetubi_icon( 'arrow' ); ?>
                </a>
            </div>
        </div>
    </section>

    <!-- お客様の声（本番データに差し替え推奨） -->
    <section class="voice-section" aria-labelledby="voice-title">
        <span class="voice-section__deco" aria-hidden="true"></span>
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">VOICE</p>
                <h2 class="section-head__title" id="voice-title">お客様の声</h2>
                <p class="section-head__desc">多くのお客様から信頼の声をいただいています。</p>
            </header>

            <div class="voice-grid reveal-stagger">
                <!-- 本番データに差し替え -->
                <article class="voice-card">
                    <div class="voice-card__stars" aria-label="5つ星の評価">
                        <?php for ( $i = 0; $i < 5; $i++ ) echo daikousetubi_icon( 'star' ); ?>
                    </div>
                    <p class="voice-card__quote">
                        突然の水漏れで困っていたところ、電話から30分で駆けつけてくれました。
                        作業も丁寧で、料金の説明も明朗。本当に助かりました。
                    </p>
                    <div class="voice-card__meta">
                        <span class="voice-card__name">○○市　A様</span>
                        <span class="voice-card__tag">水道修理</span>
                    </div>
                </article>

                <article class="voice-card">
                    <div class="voice-card__stars" aria-label="5つ星の評価">
                        <?php for ( $i = 0; $i < 5; $i++ ) echo daikousetubi_icon( 'star' ); ?>
                    </div>
                    <p class="voice-card__quote">
                        浴室リフォームをお願いしました。見積りから施工まで親身になって対応いただき、
                        仕上がりにも大満足。長年のお付き合いができそうです。
                    </p>
                    <div class="voice-card__meta">
                        <span class="voice-card__name">○○市　B様</span>
                        <span class="voice-card__tag">リフォーム</span>
                    </div>
                </article>

                <article class="voice-card">
                    <div class="voice-card__stars" aria-label="5つ星の評価">
                        <?php for ( $i = 0; $i < 5; $i++ ) echo daikousetubi_icon( 'star' ); ?>
                    </div>
                    <p class="voice-card__quote">
                        古くなった給湯器を交換していただきました。エコキュートの選び方まで
                        丁寧に教えてくれ、光熱費も下がって一石二鳥でした。
                    </p>
                    <div class="voice-card__meta">
                        <span class="voice-card__name">○○市　C様</span>
                        <span class="voice-card__tag">住宅設備</span>
                    </div>
                </article>
            </div>
        </div>
    </section>

    <!-- よくあるご質問 -->
    <section class="faq-section" aria-labelledby="faq-title">
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">FAQ</p>
                <h2 class="section-head__title" id="faq-title">よくあるご質問</h2>
                <p class="section-head__desc">お問い合わせの多いご質問にお答えします。</p>
            </header>

            <div class="faq-list">
                <?php
                $faqs = [
                    [
                        'q' => '見積もりは無料ですか？',
                        'a' => 'はい、お見積りは完全無料です。現地調査も含め、作業前に必ず料金をご提示してから作業に入りますので、ご安心ください。',
                    ],
                    [
                        'q' => '対応エリアはどこまでですか？',
                        'a' => '地元を中心に近隣エリアまで広く対応しています。遠方の場合もまずはお気軽にお電話でご相談ください。',
                    ],
                    [
                        'q' => '休日や夜間の対応はしてもらえますか？',
                        'a' => '水漏れなどの緊急トラブルについては365日対応しています。夜間対応はご相談ください。',
                    ],
                    [
                        'q' => '支払い方法はどんなものがありますか？',
                        'a' => '現金・銀行振込・各種クレジットカードに対応しています。工事内容によっては分割払いもご相談いただけます。',
                    ],
                    [
                        'q' => '工事期間はどのくらいかかりますか？',
                        'a' => '修理の場合は当日完了が基本。リフォームは内容により数日〜数週間いただきます。事前に工程表をお渡しします。',
                    ],
                ];
                foreach ( $faqs as $i => $faq ) :
                ?>
                <details class="faq-item">
                    <summary class="faq-item__q">
                        <span class="faq-item__q-mark">Q</span>
                        <span class="faq-item__q-text"><?php echo esc_html( $faq['q'] ); ?></span>
                        <svg class="faq-item__q-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <polyline points="6 9 12 15 18 9"/>
                        </svg>
                    </summary>
                    <div class="faq-item__a"><?php echo esc_html( $faq['a'] ); ?></div>
                </details>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <?php get_template_part( 'template-parts/cta' ); ?>

</main>

<?php get_footer(); ?>
