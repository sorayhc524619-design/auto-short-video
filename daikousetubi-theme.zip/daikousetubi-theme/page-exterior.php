<?php
/**
 * Template Name: エクステリア・外溝工事
 */
get_header(); ?>

<main id="main-content" class="site-main page-main" role="main">

    <?php
    get_template_part( 'template-parts/page-hero', null, [
        'label' => 'EXTERIOR',
        'title' => 'エクステリア・外溝工事',
        'desc'  => '駐車場・フェンス・門扉・庭まわりまで、<br>外まわりの工事をトータルにご提案します。',
        'icon'  => 'fence',
    ] );
    ?>

    <section class="menu-section">
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">WORKS</p>
                <h2 class="section-head__title">対応工事メニュー</h2>
                <p class="section-head__desc">外まわりのお悩みをまとめてご相談ください。</p>
            </header>
            <div class="menu-grid">
                <?php
                $items = [
                    [ 'icon' => 'home',  'title' => '駐車場工事', 'desc' => 'コンクリート・アスファルト・カーポート設置など、駐車スペースを快適に整備します。' ],
                    [ 'icon' => 'fence', 'title' => 'フェンス・塀工事', 'desc' => 'プライバシーと防犯を両立するフェンス・ブロック塀の設置・修理を行います。' ],
                    [ 'icon' => 'tool',  'title' => '門扉・玄関アプローチ', 'desc' => '来訪者に好印象を与える門扉・インターホン・玄関アプローチを整備。' ],
                    [ 'icon' => 'grid',  'title' => '庭・ガーデニング工事', 'desc' => '芝生・砂利敷き・植栽・花壇づくりなど、庭まわりをきれいに整えます。' ],
                    [ 'icon' => 'water', 'title' => '排水・側溝工事', 'desc' => '雨水の排水処理・側溝の改修・浸透ますの設置など、雨水対策に対応。' ],
                    [ 'icon' => 'shield','title' => '外壁・屋根工事', 'desc' => '外壁塗装・サイディング張り替え・屋根修理など、建物外部の工事も承ります。' ],
                ];
                foreach ( $items as $item ) :
                ?>
                <article class="menu-item">
                    <div class="menu-item__icon"><?php echo daikousetubi_icon( $item['icon'] ); ?></div>
                    <h3 class="menu-item__title"><?php echo esc_html( $item['title'] ); ?></h3>
                    <p class="menu-item__desc"><?php echo esc_html( $item['desc'] ); ?></p>
                </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="case-section">
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">CASE</p>
                <h2 class="section-head__title">施工事例</h2>
                <p class="section-head__desc">これまでのエクステリア工事の事例をご紹介します。</p>
            </header>
            <div class="gallery-grid">
                <?php
                $q = new WP_Query( [
                    'post_type'      => 'post',
                    'posts_per_page' => 6,
                    'category_name'  => 'exterior',
                ] );

                if ( $q->have_posts() ) :
                    while ( $q->have_posts() ) : $q->the_post();
                ?>
                <a href="<?php the_permalink(); ?>" class="gallery-item">
                    <div class="gallery-item__img">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <?php the_post_thumbnail( 'daikousetubi-gallery' ); ?>
                        <?php else : ?>
                            <div class="gallery-item__placeholder"><?php echo daikousetubi_icon( 'fence' ); ?></div>
                        <?php endif; ?>
                    </div>
                    <div class="gallery-item__info">
                        <span class="gallery-item__cat">エクステリア</span>
                        <h3 class="gallery-item__title"><?php the_title(); ?></h3>
                    </div>
                </a>
                <?php
                    endwhile;
                    wp_reset_postdata();
                else :
                    for ( $i = 1; $i <= 6; $i++ ) :
                ?>
                <div class="gallery-item gallery-item--demo">
                    <div class="gallery-item__img">
                        <div class="gallery-item__placeholder"><?php echo daikousetubi_icon( 'fence' ); ?></div>
                    </div>
                    <div class="gallery-item__info">
                        <span class="gallery-item__cat">エクステリア</span>
                        <h3 class="gallery-item__title">施工事例 <?php echo $i; ?></h3>
                    </div>
                </div>
                <?php endfor; endif; ?>
            </div>
        </div>
    </section>

    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); if ( get_the_content() ) : ?>
    <section class="editor-section">
        <div class="container">
            <div class="entry-content"><?php the_content(); ?></div>
        </div>
    </section>
    <?php endif; endwhile; endif; ?>

    <?php get_template_part( 'template-parts/cta' ); ?>

</main>

<?php get_footer(); ?>
