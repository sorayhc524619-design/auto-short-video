<?php
/**
 * Template Name: リフォーム
 */
get_header(); ?>

<main id="main-content" class="site-main page-main" role="main">

    <?php
    get_template_part( 'template-parts/page-hero', null, [
        'label' => 'REFORM',
        'title' => 'リフォーム',
        'desc'  => 'キッチン・浴室・トイレから内装・外装まで、<br>住まいのリニューアルをトータルにサポートします。',
        'icon'  => 'home',
    ] );
    ?>

    <section class="reform-section">
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">REFORM MENU</p>
                <h2 class="section-head__title">リフォームメニュー</h2>
                <p class="section-head__desc">住まいの気になる場所をまとめてご相談ください。</p>
            </header>
            <div class="reform-cards">
                <?php
                $reforms = [
                    [
                        'icon' => 'water',
                        'title' => 'キッチンリフォーム',
                        'desc' => 'システムキッチンへの交換や対面キッチンへの変更、収納の追加など、料理がしやすい空間に生まれ変わらせます。',
                        'items' => [ 'システムキッチン交換', '対面キッチンへの変更', '食洗機・IH設置' ],
                    ],
                    [
                        'icon' => 'home',
                        'title' => '浴室リフォーム',
                        'desc' => 'ユニットバスへの交換、タイルや床の張り替えなど、毎日のバスタイムをより快適に。',
                        'items' => [ 'ユニットバス交換', 'タイル・床の改修', '浴室乾燥機の取付' ],
                    ],
                    [
                        'icon' => 'tool',
                        'title' => 'トイレリフォーム',
                        'desc' => '古いトイレをウォシュレット付きの最新機種に交換。壁紙・床の張り替えもまとめて対応します。',
                        'items' => [ 'トイレ本体交換', '壁紙・床材の張り替え', '手洗いの設置・改修' ],
                    ],
                    [
                        'icon' => 'grid',
                        'title' => '内装・外装リフォーム',
                        'desc' => '壁紙・フローリングの張り替えから外壁塗装まで、住まい全体をまとめてリフレッシュできます。',
                        'items' => [ '壁紙・クロス張り替え', 'フローリング張替え', '外壁塗装・屋根工事' ],
                    ],
                ];
                foreach ( $reforms as $r ) :
                ?>
                <article class="reform-card">
                    <div class="reform-card__icon"><?php echo daikousetubi_icon( $r['icon'] ); ?></div>
                    <div class="reform-card__body">
                        <h3 class="reform-card__title"><?php echo esc_html( $r['title'] ); ?></h3>
                        <p class="reform-card__desc"><?php echo esc_html( $r['desc'] ); ?></p>
                        <ul class="reform-card__list">
                            <?php foreach ( $r['items'] as $item ) : ?>
                                <li><?php echo daikousetubi_icon( 'check' ); ?><?php echo esc_html( $item ); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="flow-section">
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">FLOW</p>
                <h2 class="section-head__title">リフォームの流れ</h2>
                <p class="section-head__desc">お問い合わせから完工まで、丁寧にサポートします。</p>
            </header>
            <ol class="flow-list">
                <?php
                $flows = [
                    [ 'icon' => 'phone', 'title' => 'お問い合わせ',       'desc' => '電話・メールでお気軽にご連絡ください。' ],
                    [ 'icon' => 'pin',   'title' => '現地調査・お見積り', 'desc' => '無料でお伺いし、詳細なお見積りをご提示します。' ],
                    [ 'icon' => 'check', 'title' => 'ご契約・着工',       'desc' => 'ご納得いただけたらご契約。日程を調整し工事を開始します。' ],
                    [ 'icon' => 'shield','title' => '完工・アフター',     'desc' => '施工完了後も安心のアフターサポートをご提供します。' ],
                ];
                foreach ( $flows as $i => $f ) :
                ?>
                <li class="flow-item">
                    <span class="flow-item__num"><?php echo sprintf( '%02d', $i + 1 ); ?></span>
                    <div class="flow-item__icon"><?php echo daikousetubi_icon( $f['icon'] ); ?></div>
                    <h3 class="flow-item__title"><?php echo esc_html( $f['title'] ); ?></h3>
                    <p class="flow-item__desc"><?php echo esc_html( $f['desc'] ); ?></p>
                </li>
                <?php endforeach; ?>
            </ol>
        </div>
    </section>

    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); if ( get_the_content() ) : ?>
    <section class="editor-section">
        <div class="container">
            <div class="entry-content"><?php the_content(); ?></div>
        </div>
    </section>
    <?php endif; endwhile; endif; ?>

    <?php get_template_part( 'template-parts/cta' ); ?>

</main>

<?php get_footer(); ?>
