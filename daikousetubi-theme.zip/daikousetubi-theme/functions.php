<?php
/**
 * Daikousetubi Theme functions
 *
 * @package Daikousetubi
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'DAIKOUSETUBI_VERSION', '1.0.0' );
define( 'DAIKOUSETUBI_DIR', get_template_directory() );
define( 'DAIKOUSETUBI_URI', get_template_directory_uri() );


/**
 * テーマセットアップ
 */
function daikousetubi_setup() {
    load_theme_textdomain( 'daikousetubi', DAIKOUSETUBI_DIR . '/languages' );

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'custom-logo', [
        'height'      => 60,
        'width'       => 240,
        'flex-height' => true,
        'flex-width'  => true,
    ] );
    add_theme_support( 'html5', [
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
        'navigation-widgets',
    ] );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'align-wide' );

    register_nav_menus( [
        'primary' => __( 'メインナビゲーション', 'daikousetubi' ),
        'footer'  => __( 'フッターナビゲーション', 'daikousetubi' ),
    ] );

    add_image_size( 'daikousetubi-gallery', 600, 450, true );
    add_image_size( 'daikousetubi-hero', 1200, 800, true );
}
add_action( 'after_setup_theme', 'daikousetubi_setup' );


/**
 * スクリプト・スタイル読み込み
 * style.css はテーマヘッダーと全スタイルを兼ねています。
 */
function daikousetubi_enqueue_assets() {
    wp_enqueue_style(
        'daikousetubi-google-fonts',
        'https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;700;900&display=swap',
        [],
        null
    );

    // テーマ本体の style.css を読み込む（WordPress慣例）
    wp_enqueue_style(
        'daikousetubi-main',
        get_stylesheet_uri(),
        [ 'daikousetubi-google-fonts' ],
        DAIKOUSETUBI_VERSION
    );

    wp_enqueue_script(
        'daikousetubi-main',
        DAIKOUSETUBI_URI . '/assets/js/main.js',
        [],
        DAIKOUSETUBI_VERSION,
        true
    );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'daikousetubi_enqueue_assets' );


/**
 * 本文抜粋の文字数
 */
function daikousetubi_excerpt_length( $length ) {
    return 80;
}
add_filter( 'excerpt_length', 'daikousetubi_excerpt_length' );

function daikousetubi_excerpt_more( $more ) {
    return '…';
}
add_filter( 'excerpt_more', 'daikousetubi_excerpt_more' );


/**
 * ウィジェットエリア
 */
function daikousetubi_widgets_init() {
    register_sidebar( [
        'name'          => __( 'サイドバー', 'daikousetubi' ),
        'id'            => 'sidebar-1',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ] );
}
add_action( 'widgets_init', 'daikousetubi_widgets_init' );


/**
 * ナビフォールバック
 */
function daikousetubi_nav_fallback() {
    $pages = [
        '/'            => 'ホーム',
        '/plumbing/'   => '水道の工事・修理',
        '/reform/'     => 'リフォーム',
        '/equipment/'  => '住宅設備・機器',
        '/exterior/'   => 'エクステリア・外溝工事',
        '/company/'    => '会社概要',
    ];
    echo '<ul class="nav-menu">';
    foreach ( $pages as $url => $label ) {
        echo '<li class="nav-menu__item"><a href="' . esc_url( home_url( $url ) ) . '" class="nav-menu__link">' . esc_html( $label ) . '</a></li>';
    }
    echo '<li class="nav-menu__item nav-menu__item--cta"><a href="' . esc_url( home_url( '/contact/' ) ) . '" class="nav-menu__link nav-menu__link--cta">お問い合わせ</a></li>';
    echo '</ul>';
}


/**
 * ボディクラス追加
 */
function daikousetubi_body_classes( $classes ) {
    if ( ! is_singular() ) {
        $classes[] = 'hfeed';
    }
    if ( is_front_page() ) {
        $classes[] = 'is-front';
    }
    return $classes;
}
add_filter( 'body_class', 'daikousetubi_body_classes' );


/**
 * アイコンSVG取得ヘルパー
 */
function daikousetubi_icon( $name, $class = '' ) {
    $icons = [
        'phone' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.37 1.9.72 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.35 1.85.59 2.81.72A2 2 0 0 1 22 16.92z"/></svg>',
        'mail'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
        'clock' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
        'water' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/></svg>',
        'home'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
        'tool'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>',
        'shield'=> '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
        'star'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
        'zap'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
        'yen'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3l7 10 7-10M8 13h8M8 17h8M12 13v8"/></svg>',
        'pin'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
        'arrow' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>',
        'check' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
        'grid'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>',
        'fence' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21V7l3-3 3 3v14M9 21V10l3-3 3 3v11M15 21V7l3-3 3 3v14M3 14h18M3 18h18"/></svg>',
    ];

    $svg = $icons[ $name ] ?? '';
    if ( ! $svg ) {
        return '';
    }
    return '<span class="icon ' . esc_attr( $class ) . '" aria-hidden="true">' . $svg . '</span>';
}


/**
 * 電話番号・営業時間・住所
 * いずれも「外観 > カスタマイズ > 会社情報」で上書き可能。
 * 未設定の場合は既定値が使われます。
 */
function daikousetubi_tel() {
    $value = get_theme_mod( 'phone_number', '' );
    return $value !== '' ? $value : '0120-246-791';
}
function daikousetubi_tel_href() {
    return 'tel:' . preg_replace( '/[^0-9]/', '', daikousetubi_tel() );
}
function daikousetubi_hours() {
    $value = get_theme_mod( 'business_hours', '' );
    return $value !== '' ? $value : '8:00〜18:00（年中無休）';
}
function daikousetubi_address() {
    // 未設定時は空文字（テンプレート側で表示有無を判定）
    return get_theme_mod( 'company_address', '' );
}


/**
 * カスタマイザー：会社情報セクション
 * 「外観 > カスタマイズ > 会社情報」から変更できるようにする。
 */
function daikousetubi_customize_register( $wp_customize ) {
    // セクション追加
    $wp_customize->add_section( 'daikousetubi_company', [
        'title'    => __( '会社情報', 'daikousetubi' ),
        'priority' => 30,
    ] );

    // 電話番号
    $wp_customize->add_setting( 'phone_number', [
        'default'           => '0120-246-791',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ] );
    $wp_customize->add_control( 'phone_number', [
        'label'       => __( '電話番号', 'daikousetubi' ),
        'description' => __( '例：0120-246-791', 'daikousetubi' ),
        'section'     => 'daikousetubi_company',
        'type'        => 'text',
    ] );

    // 営業時間
    $wp_customize->add_setting( 'business_hours', [
        'default'           => '8:00〜18:00（年中無休）',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ] );
    $wp_customize->add_control( 'business_hours', [
        'label'       => __( '営業時間', 'daikousetubi' ),
        'description' => __( '例：8:00〜18:00（年中無休）', 'daikousetubi' ),
        'section'     => 'daikousetubi_company',
        'type'        => 'text',
    ] );

    // 住所
    $wp_customize->add_setting( 'company_address', [
        'default'           => '',
        'sanitize_callback' => 'sanitize_textarea_field',
        'transport'         => 'refresh',
    ] );
    $wp_customize->add_control( 'company_address', [
        'label'       => __( '住所', 'daikousetubi' ),
        'description' => __( '郵便番号から番地まで（改行可）', 'daikousetubi' ),
        'section'     => 'daikousetubi_company',
        'type'        => 'textarea',
    ] );
}
add_action( 'customize_register', 'daikousetubi_customize_register' );


/**
 * カスタム投稿タイプ：施工事例（works）
 * 施工事例をブログ記事と分けて管理できるようにする。
 */
function daikousetubi_register_post_types() {
    register_post_type( 'works', [
        'labels' => [
            'name'               => __( '施工事例', 'daikousetubi' ),
            'singular_name'      => __( '施工事例', 'daikousetubi' ),
            'menu_name'          => __( '施工事例', 'daikousetubi' ),
            'add_new'            => __( '新規追加', 'daikousetubi' ),
            'add_new_item'       => __( '施工事例を新規追加', 'daikousetubi' ),
            'edit_item'          => __( '施工事例を編集', 'daikousetubi' ),
            'new_item'           => __( '新しい施工事例', 'daikousetubi' ),
            'view_item'          => __( '施工事例を表示', 'daikousetubi' ),
            'search_items'       => __( '施工事例を検索', 'daikousetubi' ),
            'not_found'          => __( '施工事例が見つかりません', 'daikousetubi' ),
            'not_found_in_trash' => __( 'ゴミ箱に施工事例はありません', 'daikousetubi' ),
            'all_items'          => __( '施工事例一覧', 'daikousetubi' ),
        ],
        'public'       => true,
        'has_archive'  => true,
        'show_in_rest' => true,
        'menu_icon'    => 'dashicons-hammer',
        'rewrite'      => [ 'slug' => 'works' ],
        'supports'     => [ 'title', 'editor', 'thumbnail', 'excerpt' ],
        'taxonomies'   => [ 'category' ],
    ] );

    // 既存の「カテゴリー」を施工事例でも使えるようにする
    register_taxonomy_for_object_type( 'category', 'works' );
}
add_action( 'init', 'daikousetubi_register_post_types' );
