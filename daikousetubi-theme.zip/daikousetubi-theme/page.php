<?php
/**
 * 固定ページ デフォルトテンプレート
 */
get_header(); ?>

<main id="main-content" class="site-main page-main" role="main">

    <?php while ( have_posts() ) : the_post(); ?>
        <div class="page-hero">
            <span class="page-hero__deco page-hero__deco--1" aria-hidden="true"></span>
            <span class="page-hero__deco page-hero__deco--2" aria-hidden="true"></span>
            <div class="container">
                <div class="page-hero__inner">
                    <h1 class="page-hero__title"><?php the_title(); ?></h1>
                </div>
            </div>
        </div>

        <div class="container">
            <article id="post-<?php the_ID(); ?>" <?php post_class( 'page-body' ); ?>>
                <div class="entry-content">
                    <?php
                    the_content();
                    wp_link_pages( [
                        'before' => '<nav class="page-links" aria-label="ページ分割">',
                        'after'  => '</nav>',
                    ] );
                    ?>
                </div>
            </article>
        </div>
    <?php endwhile; ?>

</main>

<?php get_footer(); ?>
