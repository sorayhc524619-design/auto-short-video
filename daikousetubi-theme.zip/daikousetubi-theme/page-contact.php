<?php
/**
 * Template Name: お問い合わせ
 */
get_header(); ?>

<main id="main-content" class="site-main page-main" role="main">

    <?php
    get_template_part( 'template-parts/page-hero', null, [
        'label' => 'CONTACT',
        'title' => 'お問い合わせ',
        'desc'  => 'お気軽にご相談・お見積りをご依頼ください。<br>通常1営業日以内にご連絡いたします。',
        'icon'  => 'mail',
    ] );
    ?>

    <section class="contact-section">
        <div class="container">

            <div class="contact-tel">
                <div class="contact-tel__icon"><?php echo daikousetubi_icon( 'phone' ); ?></div>
                <div class="contact-tel__body">
                    <p class="contact-tel__label">お急ぎの方・緊急の修理依頼はお電話で</p>
                    <a href="<?php echo esc_attr( daikousetubi_tel_href() ); ?>" class="contact-tel__num">
                        <?php echo esc_html( daikousetubi_tel() ); ?>
                    </a>
                    <p class="contact-tel__hours">受付時間：<?php echo esc_html( daikousetubi_hours() ); ?></p>
                </div>
            </div>

            <div class="contact-form-box">
                <header class="contact-form-box__head">
                    <h2 class="contact-form-box__title">
                        <?php echo daikousetubi_icon( 'mail' ); ?>
                        <span>メールでのお問い合わせ</span>
                    </h2>
                    <p class="contact-form-box__note">
                        <?php echo daikousetubi_icon( 'shield' ); ?>
                        <span>Contact Form 7 等のプラグインのショートコードに差し替えてください。<br>
                        例：<code>[contact-form-7 id="1" title="お問い合わせ"]</code></span>
                    </p>
                </header>

                <form class="contact-form" id="contact-form" novalidate>
                    <div class="form-row">
                        <label class="form-label" for="cf-name">
                            お名前 <span class="form-required">必須</span>
                        </label>
                        <input class="form-input" type="text" id="cf-name" name="name" placeholder="例：山田 太郎" required>
                    </div>
                    <div class="form-row">
                        <label class="form-label" for="cf-email">
                            メールアドレス <span class="form-required">必須</span>
                        </label>
                        <input class="form-input" type="email" id="cf-email" name="email" placeholder="例：example@email.com" required>
                    </div>
                    <div class="form-row">
                        <label class="form-label" for="cf-tel">電話番号</label>
                        <input class="form-input" type="tel" id="cf-tel" name="tel" placeholder="例：090-0000-0000">
                    </div>
                    <div class="form-row">
                        <label class="form-label" for="cf-service">
                            お問い合わせ種別 <span class="form-required">必須</span>
                        </label>
                        <select class="form-select" id="cf-service" name="service" required>
                            <option value="">選択してください</option>
                            <option value="water">水道の工事・修理</option>
                            <option value="reform">リフォーム</option>
                            <option value="equipment">住宅設備・機器</option>
                            <option value="exterior">エクステリア・外溝工事</option>
                            <option value="other">その他</option>
                        </select>
                    </div>
                    <div class="form-row">
                        <label class="form-label" for="cf-message">
                            お問い合わせ内容 <span class="form-required">必須</span>
                        </label>
                        <textarea class="form-textarea" id="cf-message" name="message" rows="6" placeholder="お気軽にご記入ください" required></textarea>
                    </div>
                    <div class="form-row form-row--privacy">
                        <label class="form-checkbox">
                            <input type="checkbox" name="privacy" required>
                            <span><a href="<?php echo esc_url( get_privacy_policy_url() ); ?>" target="_blank" rel="noopener">プライバシーポリシー</a>に同意します</span>
                        </label>
                    </div>
                    <div class="form-submit">
                        <button type="submit" class="btn btn--primary btn--lg">
                            <span>送信する</span>
                            <?php echo daikousetubi_icon( 'arrow' ); ?>
                        </button>
                    </div>
                </form>
            </div>

        </div>
    </section>

</main>

<?php get_footer(); ?>
