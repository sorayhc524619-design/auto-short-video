/**
 * Daikousetubi Theme - Main JS
 * 2026年刷新版：
 *  - ドロワーメニュー
 *  - ヘッダー追従（スクロール量で変化）
 *  - スクロール進捗バー
 *  - アンカーのスムーズスクロール
 *  - reveal / reveal-stagger（IntersectionObserver）
 *  - モバイル sticky CTA の表示制御
 *  - お問い合わせフォーム 簡易バリデーション
 */
(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {

        /* ---- ハンバーガーメニュー ---- */
        const hamburger = document.getElementById('hamburger');
        const drawer    = document.getElementById('drawer-menu');
        const overlay   = document.getElementById('drawer-overlay');

        const openDrawer = function () {
            hamburger.classList.add('is-open');
            drawer.classList.add('is-open');
            overlay.classList.add('is-open');
            hamburger.setAttribute('aria-expanded', 'true');
            drawer.setAttribute('aria-hidden', 'false');
            document.body.style.overflow = 'hidden';
        };

        const closeDrawer = function () {
            hamburger.classList.remove('is-open');
            drawer.classList.remove('is-open');
            overlay.classList.remove('is-open');
            hamburger.setAttribute('aria-expanded', 'false');
            drawer.setAttribute('aria-hidden', 'true');
            document.body.style.overflow = '';
        };

        if (hamburger && drawer && overlay) {
            hamburger.addEventListener('click', function () {
                drawer.classList.contains('is-open') ? closeDrawer() : openDrawer();
            });
            overlay.addEventListener('click', closeDrawer);
            drawer.querySelectorAll('a').forEach(function (link) {
                link.addEventListener('click', closeDrawer);
            });
            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape' && drawer.classList.contains('is-open')) {
                    closeDrawer();
                }
            });
        }


        /* ---- スクロール時：ヘッダー／トップボタン／進捗バー／モバイルCTA ---- */
        const header       = document.getElementById('site-header');
        const toTop        = document.getElementById('to-top');
        const progress     = document.getElementById('scroll-progress');
        const mobileCta    = document.getElementById('sticky-mobile-cta');

        const handleScroll = function () {
            const y        = window.scrollY;
            const maxY     = document.documentElement.scrollHeight - window.innerHeight;
            const ratio    = maxY > 0 ? (y / maxY) : 0;

            // ヘッダー（浅いスクロールで影、深いスクロール200px以降ですりガラス化）
            if (header) {
                header.classList.toggle('is-scrolled', y > 10);
                header.classList.toggle('is-scrolled-deep', y > 200);
            }
            // 進捗バー
            if (progress) {
                progress.style.width = (ratio * 100) + '%';
            }
            // トップへ戻る
            if (toTop) {
                toTop.classList.toggle('is-visible', y > 400);
            }
            // モバイル用 Sticky CTA：200px以上スクロールで出現
            if (mobileCta) {
                mobileCta.classList.toggle('is-visible', y > 200);
            }
        };
        window.addEventListener('scroll', handleScroll, { passive: true });
        window.addEventListener('resize', handleScroll, { passive: true });
        handleScroll();

        if (toTop) {
            toTop.addEventListener('click', function () {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }


        /* ---- アンカーリンクのスムーススクロール ---- */
        document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
            anchor.addEventListener('click', function (e) {
                const href = this.getAttribute('href');
                if (href === '#' || href.length < 2) return;
                const target = document.querySelector(href);
                if (!target) return;
                e.preventDefault();
                const headerH = header ? header.offsetHeight : 0;
                const top = target.getBoundingClientRect().top + window.scrollY - headerH - 16;
                window.scrollTo({ top: top, behavior: 'smooth' });
            });
        });


        /* ---- スクロール出現アニメーション ---- */
        // 基本要素に .reveal を自動付与
        const revealTargets = document.querySelectorAll(
            '.service-card, .reason-item, .gallery-item, .menu-item, ' +
            '.reform-card, .flow-item, .equipment-card, .section-head, ' +
            '.stat-item, .voice-card, .faq-item'
        );

        if ('IntersectionObserver' in window && revealTargets.length) {
            revealTargets.forEach(function (el) { el.classList.add('reveal'); });

            const observer = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.12, rootMargin: '0px 0px -50px 0px' });

            revealTargets.forEach(function (el, i) {
                el.style.transitionDelay = ((i % 4) * 0.08) + 's';
                observer.observe(el);
            });
        }

        // reveal-up / reveal-left / reveal-right / reveal-stagger
        const variantTargets = document.querySelectorAll(
            '.reveal-up, .reveal-left, .reveal-right, .reveal-stagger'
        );
        if ('IntersectionObserver' in window && variantTargets.length) {
            const variantObserver = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        variantObserver.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
            variantTargets.forEach(function (el) { variantObserver.observe(el); });
        }


        /* ---- FAQ アコーディオン ---- */
        // <details>を使っているため基本はブラウザ任せ。
        // ただし同時に1つだけ開きたい場合は下記を有効化：
        // document.querySelectorAll('.faq-item').forEach(function(item) {
        //     item.addEventListener('toggle', function() {
        //         if (item.open) {
        //             document.querySelectorAll('.faq-item').forEach(function(other){
        //                 if (other !== item) other.open = false;
        //             });
        //         }
        //     });
        // });


        /* ---- お問い合わせフォーム 簡易バリデーション ---- */
        const contactForm = document.getElementById('contact-form');
        if (contactForm) {
            contactForm.addEventListener('submit', function (e) {
                if (!contactForm.checkValidity()) {
                    e.preventDefault();
                    contactForm.querySelector(':invalid')?.focus();
                    return;
                }
                // Contact Form 7等のプラグインと差し替える場合、以下は削除してください
                e.preventDefault();
                alert('このフォームはサンプル表示です。\nContact Form 7 プラグインのショートコードに差し替えてご利用ください。');
            });
        }

    });
})();
