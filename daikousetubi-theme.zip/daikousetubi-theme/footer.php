</div><!-- /.page-wrapper -->

<footer class="site-footer" role="contentinfo">

    <div class="footer-cta">
        <div class="container">
            <div class="footer-cta__inner">
                <div class="footer-cta__text">
                    <p class="footer-cta__label">お気軽にご相談ください</p>
                    <h2 class="footer-cta__title">水まわりのお悩み、まるごと解決します</h2>
                </div>
                <div class="footer-cta__btns">
                    <a href="<?php echo esc_attr( daikousetubi_tel_href() ); ?>" class="btn btn--white btn--lg">
                        <?php echo daikousetubi_icon( 'phone' ); ?>
                        <span class="btn__main"><?php echo esc_html( daikousetubi_tel() ); ?></span>
                        <span class="btn__sub"><?php echo esc_html( daikousetubi_hours() ); ?></span>
                    </a>
                    <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn btn--ghost btn--lg">
                        <?php echo daikousetubi_icon( 'mail' ); ?>
                        <span>メールで相談する</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="footer-main">
        <div class="container">
            <div class="footer-grid footer-grid--4col">

                <!-- ブランド・大きなロゴ -->
                <div class="footer-col footer-col--brand">
                    <div class="footer-logo">
                        <?php if ( has_custom_logo() ) : ?>
                            <?php the_custom_logo(); ?>
                        <?php else : ?>
                            <span class="footer-logo__text"><?php bloginfo( 'name' ); ?></span>
                        <?php endif; ?>
                    </div>
                    <p class="footer-brand-statement">
                        地域に根ざして30年。<br>
                        暮らしの水まわりを、まるごと守り続けます。
                    </p>
                    <p class="footer-about">
                        水道工事・リフォーム・住宅設備の専門会社として、
                        地域のみなさまの快適な暮らしを支えています。
                    </p>
                    <!-- SNSアイコン（プレースホルダー） -->
                    <div class="footer-sns" aria-label="<?php esc_attr_e( 'SNS', 'daikousetubi' ); ?>">
                        <a href="#" class="footer-sns__link" aria-label="X（Twitter）">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M18.244 2H21l-6.52 7.45L22 22h-6.79l-4.76-6.23L4.9 22H2.14l6.97-7.97L2 2h6.96l4.3 5.69L18.244 2zm-2.38 18h1.67L7.22 4H5.46l10.404 16z"/></svg>
                        </a>
                        <a href="#" class="footer-sns__link" aria-label="Instagram">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
                        </a>
                        <a href="#" class="footer-sns__link" aria-label="Facebook">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M22 12a10 10 0 1 0-11.56 9.88v-6.99H7.9V12h2.54V9.8c0-2.51 1.49-3.9 3.78-3.9 1.1 0 2.24.2 2.24.2v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56V12h2.77l-.44 2.89h-2.33v6.99A10 10 0 0 0 22 12z"/></svg>
                        </a>
                    </div>
                </div>

                <!-- サービス -->
                <div class="footer-col">
                    <h3 class="footer-col__title">サービス</h3>
                    <ul class="footer-links">
                        <li><a href="<?php echo esc_url( home_url( '/plumbing/' ) ); ?>">水道の工事・修理</a></li>
                        <li><a href="<?php echo esc_url( home_url( '/reform/' ) ); ?>">リフォーム</a></li>
                        <li><a href="<?php echo esc_url( home_url( '/equipment/' ) ); ?>">住宅設備・機器</a></li>
                        <li><a href="<?php echo esc_url( home_url( '/exterior/' ) ); ?>">エクステリア・外溝工事</a></li>
                    </ul>
                </div>

                <!-- 会社情報 -->
                <div class="footer-col">
                    <h3 class="footer-col__title">会社情報</h3>
                    <ul class="footer-links">
                        <li><a href="<?php echo esc_url( home_url( '/company/' ) ); ?>">会社概要</a></li>
                        <li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>">お問い合わせ</a></li>
                        <li><a href="<?php echo esc_url( get_privacy_policy_url() ); ?>">プライバシーポリシー</a></li>
                    </ul>
                </div>

                <!-- お問い合わせ・営業時間 -->
                <div class="footer-col">
                    <h3 class="footer-col__title">お問い合わせ</h3>
                    <address class="footer-address">
                        <?php
                        $footer_address = daikousetubi_address();
                        if ( $footer_address ) :
                            echo wp_kses_post( nl2br( esc_html( $footer_address ) ) );
                            echo '<br>';
                        else :
                        ?>
                        〒000-0000<br>
                        ○○県○○市○○町0-0-0<br>
                        <?php endif; ?>
                        TEL：<a href="<?php echo esc_attr( daikousetubi_tel_href() ); ?>"><?php echo esc_html( daikousetubi_tel() ); ?></a><br>
                        営業時間：<?php echo esc_html( daikousetubi_hours() ); ?>
                    </address>
                </div>

            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <div class="container">
            <p class="copyright">
                &copy; <?php echo esc_html( date_i18n( 'Y' ) ); ?>
                <?php bloginfo( 'name' ); ?>. All Rights Reserved.
            </p>
        </div>
    </div>

</footer>

<button class="to-top" id="to-top" type="button" aria-label="ページ上部へ戻る">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <polyline points="18 15 12 9 6 15"/>
    </svg>
</button>

<!-- モバイル用 Sticky CTA バー（768px以下のみ表示） -->
<div class="sticky-mobile-cta" id="sticky-mobile-cta" aria-label="<?php esc_attr_e( 'お問い合わせ', 'daikousetubi' ); ?>">
    <div class="sticky-mobile-cta__grid">
        <a href="<?php echo esc_attr( daikousetubi_tel_href() ); ?>" class="sticky-mobile-cta__btn sticky-mobile-cta__btn--tel">
            <?php echo daikousetubi_icon( 'phone' ); ?>
            <span>電話で相談</span>
        </a>
        <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="sticky-mobile-cta__btn sticky-mobile-cta__btn--mail">
            <?php echo daikousetubi_icon( 'mail' ); ?>
            <span>お問い合わせ</span>
        </a>
    </div>
</div>

<?php wp_footer(); ?>
</body>
</html>
