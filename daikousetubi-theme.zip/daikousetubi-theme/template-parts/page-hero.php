<?php
/**
 * ページヒーロー共通パーツ
 *
 * @var array $args ['label' => '', 'title' => '', 'desc' => '', 'icon' => '']
 */
$label = $args['label'] ?? '';
$title = $args['title'] ?? get_the_title();
$desc  = $args['desc']  ?? '';
$icon  = $args['icon']  ?? '';
?>
<div class="page-hero page-hero--service">
    <!-- ブロブ装飾（ぼんやり浮かぶ丸） -->
    <span class="page-hero__deco page-hero__deco--1" aria-hidden="true"></span>
    <span class="page-hero__deco page-hero__deco--2" aria-hidden="true"></span>
    <span class="page-hero__deco page-hero__deco--3" aria-hidden="true"></span>
    <div class="container">
        <div class="page-hero__grid">
            <div class="page-hero__inner">
                <?php if ( $label ) : ?>
                    <p class="page-hero__label"><?php echo esc_html( $label ); ?></p>
                <?php endif; ?>
                <h1 class="page-hero__title">
                    <span class="hero__title-accent"><?php echo esc_html( $title ); ?></span>
                </h1>
                <?php if ( $desc ) : ?>
                    <p class="page-hero__desc"><?php echo wp_kses_post( $desc ); ?></p>
                <?php endif; ?>
                <div class="page-hero__btns">
                    <a href="<?php echo esc_attr( daikousetubi_tel_href() ); ?>" class="btn btn--primary">
                        <?php echo daikousetubi_icon( 'phone' ); ?>
                        <span>電話で相談する</span>
                    </a>
                    <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn btn--outline">
                        <?php echo daikousetubi_icon( 'mail' ); ?>
                        <span>メールで相談</span>
                    </a>
                </div>
            </div>
            <?php if ( $icon ) : ?>
            <div class="page-hero__visual" aria-hidden="true">
                <div class="page-hero__visual-bg"></div>
                <div class="page-hero__visual-icon">
                    <?php echo daikousetubi_icon( $icon ); ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
