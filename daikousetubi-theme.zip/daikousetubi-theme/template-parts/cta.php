<?php
/**
 * 共通お問い合わせCTAセクション（刷新版）
 * 背景に大きな装飾アイコン、見出し特大化、電話・フォームの2CTA
 */
?>
<section class="cta-section" aria-labelledby="cta-section-title">
    <span class="cta-section__deco cta-section__deco--1" aria-hidden="true"></span>
    <span class="cta-section__deco cta-section__deco--2" aria-hidden="true"></span>
    <!-- 背景の大きな装飾アイコン -->
    <div class="cta-section__hugeicon" aria-hidden="true">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.37 1.9.72 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.35 1.85.59 2.81.72A2 2 0 0 1 22 16.92z"/>
        </svg>
    </div>

    <div class="container">
        <div class="cta-section__inner">
            <p class="cta-section__label">CONTACT</p>
            <h2 class="cta-section__title" id="cta-section-title">お気軽にご相談ください</h2>
            <p class="cta-section__desc">
                ご相談・お見積りは無料です。<br>
                どんな小さなことでもお気軽にお問い合わせください。
            </p>
            <div class="cta-section__btns">
                <a href="<?php echo esc_attr( daikousetubi_tel_href() ); ?>" class="btn btn--white btn--lg">
                    <?php echo daikousetubi_icon( 'phone' ); ?>
                    <span class="btn__main"><?php echo esc_html( daikousetubi_tel() ); ?></span>
                    <span class="btn__sub">通話料無料 <?php echo esc_html( daikousetubi_hours() ); ?></span>
                </a>
                <a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>" class="btn btn--ghost btn--lg">
                    <?php echo daikousetubi_icon( 'mail' ); ?>
                    <span>お問い合わせフォーム</span>
                </a>
            </div>
        </div>
    </div>
</section>
