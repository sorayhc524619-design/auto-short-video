<?php
/**
 * Template Name: 会社概要
 */
get_header(); ?>

<main id="main-content" class="site-main page-main" role="main">

    <?php
    get_template_part( 'template-parts/page-hero', null, [
        'label' => 'COMPANY',
        'title' => '会社概要',
        'desc'  => '地域のみなさまの「困った」に寄り添い続けて、<br>私たちは地域密着で営業しています。',
        'icon'  => 'shield',
    ] );
    ?>

    <section class="company-section">
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">ABOUT</p>
                <h2 class="section-head__title">会社情報</h2>
            </header>
            <div class="company-table-wrap">
                <table class="company-table">
                    <tbody>
                        <tr><th scope="row">会社名</th><td>大光設備株式会社</td></tr>
                        <tr><th scope="row">代表者</th><td>代表取締役 ○○ ○○</td></tr>
                        <tr><th scope="row">所在地</th><td>〒000-0000<br>○○県○○市○○町0-0-0</td></tr>
                        <tr>
                            <th scope="row">電話番号</th>
                            <td>
                                <a href="<?php echo esc_attr( daikousetubi_tel_href() ); ?>" class="company-table__tel">
                                    <?php echo esc_html( daikousetubi_tel() ); ?>
                                </a>
                                （通話料無料）
                            </td>
                        </tr>
                        <tr><th scope="row">営業時間</th><td><?php echo esc_html( daikousetubi_hours() ); ?></td></tr>
                        <tr><th scope="row">設立</th><td>○○年○○月</td></tr>
                        <tr><th scope="row">事業内容</th><td>水道工事・修理／リフォーム工事／<br>住宅設備機器の販売・設置・交換／<br>エクステリア・外溝工事</td></tr>
                        <tr><th scope="row">保有資格</th><td>給水装置工事主任技術者／<br>排水設備工事責任技術者／<br>建設業許可（○○県知事許可）</td></tr>
                        <tr><th scope="row">加盟団体</th><td>○○水道事業指定工事店</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <section class="message-section">
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">MESSAGE</p>
                <h2 class="section-head__title">代表メッセージ</h2>
            </header>
            <div class="message-block">
                <div class="message-block__avatar" aria-hidden="true">
                    <?php echo daikousetubi_icon( 'shield' ); ?>
                </div>
                <div class="message-block__body">
                    <p>
                        大光設備は、地域のみなさまの「困った」に誠実に向き合い、
                        迅速・丁寧・明朗なサービスを提供し続けることを使命としています。
                    </p>
                    <p>
                        水まわりのトラブルは、生活に直結する緊急性の高い問題です。
                        だからこそ、私たちは年中無休・最短当日対応を徹底しています。
                        お客様に「頼んでよかった」と思っていただける仕事を、これからも続けてまいります。
                    </p>
                    <p class="message-block__sign">代表取締役 ○○ ○○</p>
                </div>
            </div>
        </div>
    </section>

    <section class="access-section">
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">ACCESS</p>
                <h2 class="section-head__title">アクセス</h2>
            </header>
            <div class="map-wrap">
                <div class="map-placeholder">
                    <div class="map-placeholder__icon"><?php echo daikousetubi_icon( 'pin' ); ?></div>
                    <p class="map-placeholder__main">Googleマップをここに埋め込みます</p>
                    <p class="map-placeholder__sub">WordPress管理画面から住所を設定してください</p>
                </div>
            </div>
        </div>
    </section>

    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); if ( get_the_content() ) : ?>
    <section class="editor-section">
        <div class="container">
            <div class="entry-content"><?php the_content(); ?></div>
        </div>
    </section>
    <?php endif; endwhile; endif; ?>

    <?php get_template_part( 'template-parts/cta' ); ?>

</main>

<?php get_footer(); ?>
