<?php
/**
 * Template Name: 水道の工事・修理
 */
get_header(); ?>

<main id="main-content" class="site-main page-main" role="main">

    <?php
    get_template_part( 'template-parts/page-hero', null, [
        'label' => 'WATER WORKS',
        'title' => '水道の工事・修理',
        'desc'  => '水漏れ・詰まり・給排水管工事まで、<br>水まわりのトラブルに年中無休で迅速対応します。',
        'icon'  => 'water',
    ] );
    ?>

    <section class="menu-section">
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">SERVICE MENU</p>
                <h2 class="section-head__title">対応メニュー</h2>
                <p class="section-head__desc">こんなお困りごと、すべてお任せください。</p>
            </header>
            <div class="menu-grid">
                <?php
                $items = [
                    [ 'icon' => 'water', 'title' => '水漏れ修理', 'desc' => '蛇口・シャワー・給水管・排水管など、あらゆる水漏れに対応します。' ],
                    [ 'icon' => 'tool',  'title' => 'トイレの詰まり・修理', 'desc' => '詰まりの解消から部品交換・ウォシュレット取付まで対応します。' ],
                    [ 'icon' => 'zap',   'title' => '排水管の詰まり', 'desc' => '台所・浴室・洗面台の排水詰まりを高圧洗浄で解決します。' ],
                    [ 'icon' => 'home',  'title' => '給水管・排水管工事', 'desc' => '老朽化した配管の交換・新規引込み工事に対応します。' ],
                    [ 'icon' => 'tool',  'title' => '蛇口・水栓交換', 'desc' => '蛇口の水漏れ・老朽化した水栓の交換・取付を行います。' ],
                    [ 'icon' => 'shield','title' => '止水栓・メーター工事', 'desc' => '止水栓の交換・水道メーター周りの修理工事に対応します。' ],
                ];
                foreach ( $items as $item ) :
                ?>
                <article class="menu-item">
                    <div class="menu-item__icon"><?php echo daikousetubi_icon( $item['icon'] ); ?></div>
                    <h3 class="menu-item__title"><?php echo esc_html( $item['title'] ); ?></h3>
                    <p class="menu-item__desc"><?php echo esc_html( $item['desc'] ); ?></p>
                </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="price-section">
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">PRICE</p>
                <h2 class="section-head__title">料金目安</h2>
                <p class="section-head__desc">※作業前に必ずお見積りをご提示します。追加料金は発生しません。</p>
            </header>
            <div class="price-table-wrap">
                <table class="price-table">
                    <thead>
                        <tr>
                            <th scope="col">作業内容</th>
                            <th scope="col">料金目安（税込）</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr><th scope="row">蛇口のパッキン交換</th><td>5,500円〜</td></tr>
                        <tr><th scope="row">トイレの詰まり除去</th><td>8,800円〜</td></tr>
                        <tr><th scope="row">排水管高圧洗浄</th><td>15,400円〜</td></tr>
                        <tr><th scope="row">蛇口・水栓交換（部品別）</th><td>11,000円〜</td></tr>
                        <tr><th scope="row">給水管修理・交換</th><td>要お見積り</td></tr>
                    </tbody>
                </table>
            </div>
            <p class="price-note">※上記は目安です。状況により異なりますので、まずはご相談ください。</p>
        </div>
    </section>

    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); if ( get_the_content() ) : ?>
    <section class="editor-section">
        <div class="container">
            <div class="entry-content"><?php the_content(); ?></div>
        </div>
    </section>
    <?php endif; endwhile; endif; ?>

    <?php get_template_part( 'template-parts/cta' ); ?>

</main>

<?php get_footer(); ?>
