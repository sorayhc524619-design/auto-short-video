<?php
/**
 * Template Name: 住宅設備・機器
 */
get_header(); ?>

<main id="main-content" class="site-main page-main" role="main">

    <?php
    get_template_part( 'template-parts/page-hero', null, [
        'label' => 'EQUIPMENT',
        'title' => '住宅設備・機器',
        'desc'  => '給湯器・エアコン・ウォシュレットなど、<br>住宅設備機器の販売・設置・交換に対応します。',
        'icon'  => 'tool',
    ] );
    ?>

    <section class="menu-section">
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">PRODUCTS</p>
                <h2 class="section-head__title">取り扱い設備・機器</h2>
                <p class="section-head__desc">各メーカーの最新機種を取り扱っています。</p>
            </header>
            <div class="equipment-grid">
                <?php
                $products = [
                    [ 'icon' => 'zap',   'title' => '給湯器',             'desc' => 'ガス給湯器・エコキュート・電気温水器の交換・新規設置に対応します。', 'badge' => '取替え最短当日' ],
                    [ 'icon' => 'water', 'title' => 'エアコン',           'desc' => 'エアコンの新規設置・買い替え・取外しまでワンストップで対応。',      'badge' => '工事込みでお得' ],
                    [ 'icon' => 'tool',  'title' => 'トイレ・ウォシュレット', 'desc' => '温水洗浄便座・タンクレストイレへの交換にも対応します。',        'badge' => '即日対応可' ],
                    [ 'icon' => 'home',  'title' => 'キッチン設備',       'desc' => 'IHクッキングヒーター・食洗機・レンジフードの設置・交換。',          'badge' => '補助金対象あり' ],
                    [ 'icon' => 'shield','title' => '浴室設備',           'desc' => '浴室暖房乾燥機・追い炊き給湯器・シャワーヘッド等の交換。',        'badge' => '省エネ対応' ],
                    [ 'icon' => 'grid',  'title' => '洗面・水まわり設備', 'desc' => '洗面台・洗濯機用水栓・洗濯パン等の交換・新規設置。',              'badge' => '各社対応' ],
                ];
                foreach ( $products as $p ) :
                ?>
                <article class="equipment-card">
                    <span class="equipment-card__badge"><?php echo esc_html( $p['badge'] ); ?></span>
                    <div class="equipment-card__icon"><?php echo daikousetubi_icon( $p['icon'] ); ?></div>
                    <h3 class="equipment-card__title"><?php echo esc_html( $p['title'] ); ?></h3>
                    <p class="equipment-card__desc"><?php echo esc_html( $p['desc'] ); ?></p>
                </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="maker-section">
        <div class="container">
            <header class="section-head">
                <p class="section-head__label">MAKER</p>
                <h2 class="section-head__title">取り扱いメーカー</h2>
                <p class="section-head__desc">幅広いメーカーを取り扱っていますので、ご希望の機種をお伝えください。</p>
            </header>
            <ul class="maker-list">
                <?php
                $makers = [ 'TOTO', 'LIXIL', 'パナソニック', 'リンナイ', 'ノーリツ', 'パロマ', 'ダイキン', '三菱電機', '日立', '東芝', 'コロナ', 'その他各社' ];
                foreach ( $makers as $m ) :
                ?>
                <li class="maker-item"><?php echo esc_html( $m ); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </section>

    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); if ( get_the_content() ) : ?>
    <section class="editor-section">
        <div class="container">
            <div class="entry-content"><?php the_content(); ?></div>
        </div>
    </section>
    <?php endif; endwhile; endif; ?>

    <?php get_template_part( 'template-parts/cta' ); ?>

</main>

<?php get_footer(); ?>
